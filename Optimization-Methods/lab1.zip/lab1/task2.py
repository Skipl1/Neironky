"""
Задача 2: Система с отрицательной обратной связью и запаздыванием.
"""
import matplotlib.pyplot as plt
import numpy as np
from common import (
    get_system_params, setup_time, rk4_step, compute_output,
    apply_delay, save_plot
)

# Параметры объекта
params = get_system_params()
t, steps = setup_time(params)
tau_steps = int(params['tau'] / params['dt'])

# Уставка
g = np.ones(steps)

# Моделирование системы БЕЗ запаздывания
z_clean = 0.0
y_clean = np.zeros(steps)

for n in range(steps - 1):
    e = g[n] - y_clean[n]  # Ошибка (отрицательная обратная связь)
    z_clean = rk4_step(z_clean, e, params)
    y_clean[n + 1] = compute_output(e, z_clean, params)

# Применение запаздывания к выходу
y_delay = apply_delay(y_clean, tau_steps, steps)

# Построение графика
fig = plt.figure(figsize=(10, 6))
plt.plot(t, y_clean, "-r", label="Без запаздывания", alpha=0.6)
plt.plot(t, y_delay, "--b", label=f"С запаздыванием (τ = {params['tau']}с)", linewidth=2)
plt.step(t, g, "-g", label="Уставка g(t)", where='post', alpha=0.5)
plt.grid(True, linestyle=':')
plt.legend()
plt.xlabel("Время, с")
plt.ylabel("Выход системы y(t)")
plt.title("Задача 2: Система с ОС и запаздыванием")
plt.tight_layout()

save_plot(fig, "task2_обратная_связь.png")
