
import matplotlib.pyplot as plt
import numpy as np
from common import (
    get_system_params, setup_time, rk4_step, compute_output,
    analytic_step_response, save_plot
)

# Параметры системы
params = get_system_params()
t, steps = setup_time(params)

# Ступенчатое воздействие
g = np.ones(steps)

# Начальное состояние
z = 0.0
y = np.zeros(steps)

# Моделирование (без обратной связи, без запаздывания)
for n in range(steps - 1):
    z = rk4_step(z, g[n], params)
    y[n + 1] = compute_output(g[n], z, params)

# Аналитическое решение
h_analytic = analytic_step_response(t, params)

# Построение графика
fig = plt.figure(figsize=(10, 6))
plt.plot(t, h_analytic, "-b", label="Аналитическое", linewidth=2)
plt.plot(t, y, "--r", label="Численное (Рунге-Кутта)", linewidth=2)
plt.step(t, g, "-g", label="g(t) - ступенчатое воздействие", where='post')
plt.grid(True, linestyle=':')
plt.legend()
plt.xlabel("Время, с")
plt.ylabel("Выход системы")
plt.title("Задача 1: Сравнение численного и аналитического решений (без ОС)")
plt.tight_layout()

save_plot(fig, "task1_численное_аналитическое.png")
