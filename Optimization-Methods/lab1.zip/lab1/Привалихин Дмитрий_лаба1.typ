#import "../../lib/lib.typ": *
#import "../../lib/resources/title.typ": irnitu_title 

#irnitu_title(
  subject: "Скриптовые языки программирования",
  topic: "Развёртывание и настройка сетевого взаимодействия серверов Web, App и Database",
  student: "Д.С. Привалихин",
  group: "ИСИБ-23-1",
  teacher: "А.А. Гаращенко"
)

#show: report

#counter(page).update(2)

#outline()
#pagebreak()

#include "content.typ"