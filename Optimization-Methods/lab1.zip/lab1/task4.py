"""
Задача 4: Подбор параметров ПИД-регулятора методом Зиглера-Никольса
"""
import matplotlib.pyplot as plt
import numpy as np
import os
from common import (
    get_system_params, setup_time, simulate_pid, compute_criterion, save_plot
)

# Параметры объекта
params = get_system_params(T_max=20.0)
t, steps = setup_time(params)

# Уставка
g = np.ones(steps)

# === 1. Определение K_cr и T_cr ===
# Для объекта W(p) = (p + 1) / (3p + 1)
# K_cr = 1 / K_ob * (T_ob2 / T_ob1) для пропорционального регулятора
K_cr = 1.0 / params['k_ob'] * (params['T_ob2'] / params['T_ob1'])  # = 3.0

# Критический период: T_cr ≈ 2 * pi * sqrt(T_ob1 * T_ob2)
T_cr = 2 * np.pi * np.sqrt(params['T_ob1'] * params['T_ob2'])  # ≈ 10.88 с

print(f"Критический коэффициент: K_cr = {K_cr:.3f}")
print(f"Критический период: T_cr = {T_cr:.3f} с")

# === 2. Расчёт параметров ПИД по формулам Зиглера-Никольса ===
q1_zn = 0.6 * K_cr
q2_zn = 1.2 * K_cr / T_cr
q3_zn = 0.0

print(f"\nПараметры ПИД (Зиглер-Никольс):")
print(f"  q1 (Kp) = {q1_zn:.3f}")
print(f"  q2 (Ki) = {q2_zn:.3f}")
print(f"  q3 (Kd) = {q3_zn:.3f}")

# === 3. Сравнение регуляторов ===
y_p, u_p = simulate_pid(1.0, 0.0, 0.0, steps, g, params)  # П-регулятор
y_pi, u_pi = simulate_pid(q1_zn, q2_zn, 0.0, steps, g, params)  # ПИ-регулятор ЗН
y_pid, u_pid = simulate_pid(q1_zn, q2_zn, q3_zn, steps, g, params)  # ПИД ЗН

# Критерии качества (интеграл от квадрата ошибки)
I_p = np.sum((g - y_p) ** 2) * params['dt']
I_pi = np.sum((g - y_pi) ** 2) * params['dt']
I_pid = np.sum((g - y_pid) ** 2) * params['dt']

print(f"\nКритерий качества:")
print(f"  I_0 (П-регулятор, q1=1) = {I_p:.4f}")
print(f"  I_PI (ПИ ЗН) = {I_pi:.4f}")
print(f"  I* (ПИД ЗН) = {I_pid:.4f}")

# === 4. Построение графика ===
fig = plt.figure(figsize=(10, 6))
plt.plot(t, y_p, "-b", label="П (q₁=1, q₂=q₃=0)", linewidth=2)
plt.plot(t, y_pi, "--r", label=f"ПИ (ЗН)", linewidth=2)
plt.plot(t, y_pid, "-.g", label=f"ПИД (ЗН)", linewidth=2)
plt.step(t, g, "-k", label="g(t) - уставка", where='post', linewidth=1.5)
plt.grid(True, linestyle=':')
plt.legend(loc='lower right')
plt.xlabel("Время, с")
plt.ylabel("Выход y(t)")
plt.title(f"Сравнение регуляторов (Зиглер-Никольс)\nK_cr={K_cr:.2f}, T_cr={T_cr:.2f}с")
plt.text(0.02, 0.98, f'I₀ = {I_p:.4f}\nI* = {I_pid:.4f}', transform=plt.gca().transAxes,
         verticalalignment='top', bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5),
         fontsize=10)
plt.tight_layout()

save_plot(fig, "task4_Зиглер_Никольс.png")

# Сохранение параметров в файл
script_dir = os.path.dirname(os.path.abspath(__file__))
with open(os.path.join(script_dir, "pid_params.txt"), "w", encoding="utf-8") as f:
    f.write(f"Метод Зиглера-Никольса\n")
    f.write(f"======================\n\n")
    f.write(f"Критический коэффициент: K_cr = {K_cr:.6f}\n")
    f.write(f"Критический период: T_cr = {T_cr:.6f} с\n\n")
    f.write(f"Параметры ПИД-регулятора:\n")
    f.write(f"  q1 (Kp) = {q1_zn:.6f}\n")
    f.write(f"  q2 (Ki) = {q2_zn:.6f}\n")
    f.write(f"  q3 (Kd) = {q3_zn:.6f}\n\n")
    f.write(f"Критерии качества:\n")
    f.write(f"  I_0 (П, q1=1) = {I_p:.6f}\n")
    f.write(f"  I* (ПИД ЗН) = {I_pid:.6f}\n")
