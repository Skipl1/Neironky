import matplotlib.pyplot as plt
import numpy as np
from common import (
    get_system_params, setup_time, rk4_step, compute_output,
    pid_controller, apply_delay, save_plot
)

# Параметры объекта
params = get_system_params()
t, steps = setup_time(params)
tau_steps = int(params['tau'] / params['dt'])

# Параметры ПИД-регулятора
params['q1'], params['q2'], params['q3'] = 1.5, 0.5, 0

# Уставка
g = np.ones(steps)

# Моделирование системы БЕЗ запаздывания
z_no_tau = 0.0
y_no_tau = np.zeros(steps)
u_no_tau = np.zeros(steps)
integral = 0.0
prev_error = 0.0

for n in range(steps - 1):
    # Ошибка регулирования
    error = g[n] - y_no_tau[n]
    
    # ПИД-регулятор
    u, integral, prev_error = pid_controller(error, integral, prev_error, params)
    u = np.clip(u, -10, 10)  # Насыщение
    u_no_tau[n] = u
    
    # Объект управления
    z_no_tau = rk4_step(z_no_tau, u, params)
    y_no_tau[n + 1] = compute_output(u, z_no_tau, params)

# Применение запаздывания к выходу и управлению
y_tau = apply_delay(y_no_tau, tau_steps, steps)
u_tau = apply_delay(u_no_tau, tau_steps, steps)

# Построение графиков
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 10), sharex=True)

# График 1: Выход системы
ax1.plot(t, y_no_tau, "-b", label="Без запаздывания", linewidth=2)
ax1.plot(t, y_tau, "--r", label=f"С запаздыванием (τ={params['tau']})", linewidth=2)
ax1.step(t, g, "-g", label="g(t) - уставка", where='post', linewidth=1.5)
ax1.grid(True, linestyle=':')
ax1.legend(loc='lower right')
ax1.set_ylabel("Выход y(t)")
ax1.set_title(f"Задача 3: Система с ПИД-регулятором (q1={params['q1']}, q2={params['q2']}, q3={params['q3']})")

# График 2: Управление
ax2.plot(t, u_no_tau, "-b", label="u(t) без запаздывания", linewidth=2)
ax2.plot(t, u_tau, "--r", label=f"u(t) с запаздыванием", linewidth=2)
ax2.grid(True, linestyle=':')
ax2.legend(loc='lower right')
ax2.set_xlabel("Время, с")
ax2.set_ylabel("Управление u(t)")

plt.tight_layout()

save_plot(fig, "task3_ПИД_регулятор.png")
