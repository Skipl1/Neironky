"""
Запуск всех задач лабораторной работы №1
Генерирует графики для всех четырёх задач
"""
import os
import sys
import importlib.util

# Добавляем текущую директорию в path
script_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, script_dir)

print("=" * 60)
print("Лабораторная работа №1: Методы оптимизации")
print("Запуск всех задач...")
print("=" * 60)


def run_script(name):
    """Запускает Python-скрипт по имени"""
    path = os.path.join(script_dir, name)
    spec = importlib.util.spec_from_file_location(name[:-3], path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)


# Запуск задачи 1
print("\n[1/4] Задача 1: Численное vs аналитическое решение (без ОС)")
print("-" * 60)
run_script("task1.py")

# Запуск задачи 2
print("\n[2/4] Задача 2: Система с обратной связью")
print("-" * 60)
run_script("task2.py")

# Запуск задачи 3
print("\n[3/5] Задача 3: Система с ПИД-регулятором")
print("-" * 60)
run_script("task3.py")

# Запуск задачи 4
print("\n[4/5] Задача 4: Подбор параметров ПИД (Зиглер-Никольс)")
print("-" * 60)
run_script("task4.py")

# Запуск задачи 5
print("\n[5/5] Задача 5: Метод покоординатного спуска")
print("-" * 60)
run_script("task5.py")

print("\n" + "=" * 60)
print("Все задачи выполнены успешно!")
print(f"Графики сохранены в: {os.path.join(script_dir, 'images')}")
print("=" * 60)
