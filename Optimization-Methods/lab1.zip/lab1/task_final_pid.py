import matplotlib
matplotlib.use('Agg')  # Режим генерации файлов без вывода на экран
import matplotlib.pyplot as plt
import numpy as np
import os
from collections import deque

# Параметры объекта
k_ob, T_ob1, T_ob2, tau = 1.0, 1.0, 3.0, 0.3
dt, T_max = 0.01, 15.0
steps = int(T_max / dt)
delay_steps = int(tau / dt)

t = np.linspace(0, T_max, steps)
g = np.ones(steps)

def simulate_pid(q1, q2, q3):
    y = np.zeros(steps)
    z = 0.0
    integral = 0.0
    prev_error = 0.0
    u_limit = 10.0 # Ограничение управления
    
    for n in range(steps - 1):
        error = g[n] - y[n]
        integral += error * dt
        derivative = (error - prev_error) / dt
        
        u = q1 * error + q2 * integral + q3 * derivative
        u = np.clip(u, -u_limit, u_limit)

        # Модель объекта (диф. уравнение)
        z_new = (k_ob * u - z) / T_ob2 * dt + z
        y[n + 1] = (T_ob1 / T_ob2) * k_ob * u + (1 - T_ob1 / T_ob2) * z_new
        z = z_new
        prev_error = error

    # Критерий качества + ШТРАФ за разнос
    # Если значения y слишком большие, значит система неустойчива
    if np.any(np.abs(y) > 10) or np.isnan(y).any():
        I = 1e10 # Огромный штраф
    else:
        I = np.sum((g - y)**2) * dt
        
    return y, I

def simple_coordinate_descent():
    # Начальные значения (более аккуратные)
    q = [0.5, 0.1, 0.05] 
    _, best_I = simulate_pid(*q)
    
    # Снижаем диапазон поиска, чтобы не провоцировать разнос
    # q1 (П), q2 (И), q3 (Д)
    search_ranges = [
        np.linspace(0.1, 2.0, 20), # q1
        np.linspace(0.0, 1.0, 20), # q2
        np.linspace(0.0, 0.5, 20)  # q3
    ]

    for iteration in range(3): # 3 прохода по всем координатам
        for i in range(3):
            for val in search_ranges[i]:
                q_test = list(q)
                q_test[i] = val
                _, current_I = simulate_pid(*q_test)
                
                if current_I < best_I:
                    best_I = current_I
                    q[i] = val
        print(f"Итерация {iteration+1}: q={q}, I={best_I:.4f}")
    return q

# Оптимизация
q_opt = simple_coordinate_descent()

# Результаты
y_init, I_init = simulate_pid(0.5, 0.1, 0.05)
y_opt, I_opt = simulate_pid(*q_opt)

# Визуализация
plt.figure(figsize=(10, 6))
plt.plot(t, y_init, '--b', label=f"Начальный (I={I_init:.2f})")
plt.plot(t, y_opt, '-r', label=f"Оптимальный (q1={q_opt[0]:.2f}, q2={q_opt[1]:.2f}, q3={q_opt[2]:.2f})", linewidth=2)
plt.axhline(1, color='black', linestyle=':', label="Уставка")
plt.title("Исправленный покоординатный спуск (без разноса)")
plt.xlabel("Время, с")
plt.ylabel("Выход y(t)")
plt.grid(True)
plt.legend()

# Вывод 
# plt.show() 

# Если хочешь сохранить в папку, раскомментируй ниже:
script_dir = os.path.dirname(os.path.abspath(__file__))
images_dir = os.path.join(script_dir, 'images')
os.makedirs(images_dir, exist_ok=True)
plt.savefig(os.path.join(images_dir, "task5_fixed.png"))