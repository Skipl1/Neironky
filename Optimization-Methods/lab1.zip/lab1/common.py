"""
Общие функции и параметры для моделирования систем автоматического регулирования.
"""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import os
from collections import deque

# Параметры системы по умолчанию
DEFAULT_PARAMS = {
    'k_ob': 1.0,      # Коэффициент передачи объекта
    'T_ob1': 1.0,     # Постоянная времени T1
    'T_ob2': 3.0,     # Постоянная времени T2
    'tau': 0.3,       # Запаздывание
    'dt': 0.01,       # Шаг интегрирования
    'T_max': 15.0,    # Время моделирования
}


def get_system_params(**overrides):
    """Получить параметры системы с возможностью переопределения."""
    params = DEFAULT_PARAMS.copy()
    params.update(overrides)
    return params


def setup_time(params):
    """Создать массив времени и рассчитать количество шагов."""
    steps = int(params['T_max'] / params['dt'])
    t = np.linspace(0, params['T_max'], steps)
    return t, steps


def rk4_step(z, x, params):
    """ Шаг метода Рунге-Кутты 4-го порядка."""
    k_ob, T_ob2 = params['k_ob'], params['T_ob2']
    f = lambda v: (k_ob * x - v) / T_ob2
    k1 = params['dt'] * f(z)
    k2 = params['dt'] * f(z + k1 / 2)
    k3 = params['dt'] * f(z + k2 / 2)
    k4 = params['dt'] * f(z + k3)
    return z + (k1 + 2 * k2 + 2 * k3 + k4) / 6


def compute_output(x, z, params):
    """Вычисление выхода системы y."""
    k_ob, T_ob1, T_ob2 = params['k_ob'], params['T_ob1'], params['T_ob2']
    return (T_ob1 / T_ob2) * k_ob * x + (1 - T_ob1 / T_ob2) * z


def pid_controller(error, integral, prev_error, params):
    """ ПИД-регулятор."""
    dt = params['dt']
    q1, q2, q3 = params.get('q1', 0), params.get('q2', 0), params.get('q3', 0)
    
    integral_new = integral + error * dt
    derivative = (error - prev_error) / dt
    u = q1 * error + q2 * integral_new + q3 * derivative
    return u, integral_new, error


def apply_delay(signal, tau_steps, steps):
    """Применить запаздывание к сигналу."""
    delayed = np.zeros(steps)
    for n in range(steps - tau_steps):
        delayed[n + tau_steps] = signal[n]
    return delayed


def save_plot(fig, filename, subdir='images'):
    """Сохранить график в папку images."""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    save_dir = os.path.join(script_dir, subdir)
    os.makedirs(save_dir, exist_ok=True)
    output_path = os.path.join(save_dir, filename)
    fig.savefig(output_path, dpi=150, bbox_inches='tight')
    plt.close(fig)
    print(f"График сохранён в {output_path}")
    return output_path


def analytic_step_response(t, params):
    """ Аналитическое решение для ступенчатого воздействия (без обратной связи). """
    k_ob, T_ob1, T_ob2 = params['k_ob'], params['T_ob1'], params['T_ob2']
    return k_ob * (1 - (1 - T_ob1 / T_ob2) * np.exp(-t / T_ob2))


def simulate_pid(q1, q2, q3, steps, g, params):
    """
    Моделирование системы с ПИД-регулятором.
    """
    z = 0.0
    y = np.zeros(steps)
    u = np.zeros(steps)
    integral = 0.0
    prev_error = 0.0

    for n in range(steps - 1):
        error = g[n] - y[n]
        integral_new = integral + error * params['dt']
        derivative = (error - prev_error) / params['dt'] if params['dt'] > 0 else 0
        u_val = q1 * error + q2 * integral_new + q3 * derivative
        u_val = np.clip(u_val, -10, 10)
        
        u[n] = u_val
        z = rk4_step(z, u_val, params)
        y[n + 1] = compute_output(u_val, z, params)
        
        integral = integral_new
        prev_error = error

    return y, u


def compute_criterion(y, g, dt):
    """ Квадратичный критерий качества I = ∫(g-y)²dt """
    error = g - y
    return np.sum(error ** 2) * dt
